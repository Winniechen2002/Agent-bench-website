# Agent Bench: Evaluating Agents through Long-Horizon Robotic Tasks

**Technical report · Draft v0.1 · October 9, 2026**

## Abstract

Long-horizon robotic tasks require an agent to connect a symbolic objective to a sequence of physical interactions, maintain constraints, and respond to execution feedback. Agent Bench is a simulation research platform for studying this process under explicit observation, tool, action, and resource boundaries. The current task atlas contains 200 definitions: 20 bimanual pocket-cube variants, 100 launcher-based physical-reasoning tasks, 40 Panda Tower-of-Hanoi tasks, and 40 standalone Sharpa-hand Hanoi tasks. A separate v1 evaluation platform integrates Kongming assembly/disassembly and single-Panda Rubik tasks through a public SDK, a trusted gateway, and private physical scoring. Four capability levels distinguish direct model control from observation-grounded tools, pretrained grasp assistance, and privileged state access. This report describes the task taxonomy, evaluation contract, system architecture, and available evidence. The reviewed inventory records historical complete engineering execution for 82 of the 200 core tasks; these records are neither a model success rate nor results under the current four-trial protocol. Reference solves and a real coding-agent integration check establish bounded platform functionality. Broad agent comparisons and cross-configuration reliability remain open evaluation work. [1–7]

## 1. Introduction

A robot can produce a valid plan and still fail to complete it. A ring may be grasped poorly, a released object may settle in the wrong place, or a sequence of cube turns may become unstable during reorientation. The relevant unit of evaluation is therefore the interaction loop: what the agent observes, how it chooses and implements actions, what physical changes occur, and how subsequent decisions use that feedback.

Agent Bench focuses on this connection between reasoning and execution. Tasks specify goals that extend beyond an isolated movement: redistributing rings among pegs, executing a prescribed cube transition, coordinating two arms around a launcher, or assembling interlocking pieces. The agent may retain memory and use permitted tools, but task completion is determined from the environment's physical state under a declared contract. A textual claim of success is insufficient. [1, 3, 4]

The present system has three complementary parts. First, a curated atlas presents 200 task definitions and scene illustrations. Second, capability rules describe which sources of assistance are allowed. Third, a v1 platform provides isolated SDK-based evaluation for two extension families. These parts have different coverage: the 200-task atlas is not a claim that all entries already run through the same isolated v1 backend. [1–4]

This report describes the implemented scope and its evidence. It does not report a new model, a performance advantage over another benchmark, or a controlled model comparison. Agent Bench here denotes the robotics repository in Reference 1.

## 2. Problem formulation

We describe a task as T = (g, ρ₀, O, A, K, C, S, F, B), where g is the goal, ρ₀ the initial-state distribution, O the available observations, A the legal action interface, K the permitted tools, C the constraints, S the success predicate, F the hard physical-failure predicate, and B the resource budget. This formulation adapts the repository's research overview while applying the current capability rules. [1, 3]

At decision step t, an agent maps the goal, observation history, memory, and remaining budget to a permitted tool call or robot action. Physical execution produces new observations. The intended objective is to maximize the probability of success subject to all task constraints, no hard physical failure, and budget compliance. These constraints are not exchangeable with reward: additional progress cannot compensate for a forbidden action or violated rule.

The evaluation contract must specify units, coordinate frames, action frequency, terminal criteria, and the time over which a final state must remain stable. It must also define how interruptions and unavailable accounting are represented. Otherwise, two agents can appear to solve the same task while receiving different information, assistance, or opportunities to retry.

**Public feedback and private scoring have different purposes.** Agent-visible observations enable control; the evaluator may use hidden physical state to determine completion and violations. Low-permission agents must not receive private object truth, hidden rewards, or detailed evaluator diagnostics merely because those fields are useful for scoring. Tools reconstructed from legal observations remain distinct from access to the original evaluator state. [3, 4]

## 3. Task atlas and physical environments

### 3.1 Core task inventory

The atlas snapshot fixes a total of 200 entries. A task definition is a catalog unit, not a completed rollout. Robot variants are counted separately; seeds and observation settings do not add entries. The two Hanoi groups reuse a task suite across different embodiments. The pocket-cube group contains ten transitions, each instantiated with two robot configurations. [2]

| Atlas group | Entries | Embodiment and task emphasis |
| --- | ---: | --- |
| Bimanual pocket cube | 20 | Dual ALOHA grippers or two standalone Sharpa hands; layer turns, support, handover, and sequence tracking |
| Physical reasoning | 100 | Two Panda arms operating a launcher; aiming, reloading, structural interactions, and finite ammunition |
| Panda Hanoi | 40 | Arm and parallel gripper; ring transfer, peg placement, and task-specific constraints |
| Standalone Sharpa Hanoi | 40 | Translating and rotating dexterous hand; the same full-size ring-and-peg task suite |
| **Total** | **200** | Robot variants included; test conditions excluded |

![Representative native simulation scenes from the four atlas groups.](../assets/report-scenes.jpg)

*Figure 1. Panda Hanoi (HP-H03), bimanual pocket cube (C01-AL), physical reasoning (A039), and standalone-hand Hanoi (HN-H02). These native scene renders include visual backgrounds for presentation. They do not show completed trajectories and do not expand the scope of execution evidence.*

### 3.2 Hanoi and pocket-cube tasks

Hanoi tasks connect a symbolic arrangement to physical ring manipulation. The agent must identify the movable ring, select a legal transfer, grasp it, clear the peg, and seat it at the destination under the selected task's rules. For example, HP-H03 begins with rings distributed across three pegs and requires a specified rearrangement of all five rings with a stable final state. A symbolic solution alone does not establish successful transfer. The atlas records one historical full-transfer pass for this entry under one train/seed-0 engineering condition. It does not establish success across the 40-task Panda group. [2]

The bimanual pocket-cube entries vary transitions and embodiments. C01-AL asks two ALOHA grippers to execute a clockwise top-layer turn: one supports the lower layer while the other rotates the top. Other entries involve handover, multi-axis motion, or recovery sequences. Scene checks establish initialization and task wiring, while complete two-hand execution remains unverified in the reviewed core inventory. These entries are distinct from the single-Panda Rubik extension discussed below. [2, 6]

### 3.3 Launcher-based physical reasoning

The MuJoCo suite uses contact-driven robot operation of a spring launcher. Tasks include direct targeting, toppling structures, indirect impact, persistent damage, ordered targets, protected objects, and constrained ammunition. Ground mode requires first-shot pickup and loading; loaded mode starts with the first projectile in place. Some configurations add separate yaw and elevation mechanisms that change the operation sequence. These differences must remain explicit in comparisons. [7]

The suite exposes State and Vision interfaces and a batch runner. Its engineering controller uses privileged information and authored firing plans, even though it executes through robot joint actions. It must not be labeled a vision policy. For the single- and dual-arm interfaces, 8- and 16-dimensional actions represent absolute joint targets, with a 20 ms decision interval and 1 ms physics interval. These action semantics differ from the scaled joint-offset controls used by the Isaac v1 platform. [4, 7]

Rigid glass fragmentation uses authored thresholds and fragments; it is not a continuum fracture model. Contact-triggered aiming brakes are idealized mechanisms. The current evidence therefore characterizes the implemented simulation, not the accuracy of real materials or hardware. [7]

### 3.4 Platform extensions

Kongming assembly and disassembly use two Panda arms and are integrated with the isolated SDK platform. A separate single-Panda Rubik environment supports solving and ordered sequence execution with eight controls. These extension tasks are excluded from the core count of 200. The 30 public Panda cube cases have reset acceptance, which does not imply 30 successful solves. [4–6]

The Rubik environment declares the physical model `hybrid_fixture_v1`: switchable internal constraints, support anchors, measured grasp attachment, and carrier detents assist manipulation. Public fixture transactions request legal mechanism changes; they do not substitute a solved object pose for robot execution. A sequence such as `U U'` requires both measured transitions even if its symbolic final state equals the initial state. These results must be described as fixture-assisted. [6]

## 4. Capability levels and observation permissions

Capability profile `2026-10-05-l0-l3` distinguishes four levels of permitted assistance. The current shared rules take precedence over older aspirational tool lists in the research overview. In particular, none of the four levels permits an additional pretrained action-policy tool. The evaluated model itself may have declared frozen pretrained weights. [3]

| Level | Permitted assistance | Interpretation |
| --- | --- | --- |
| L0 | Allowed RGB/proprioception; actions emitted by the model; no auxiliary tools or code execution | Direct model control |
| L1 | Vision, geometry, IK, retargeting, motion planning, and RL/optimization in an observation-derived proxy simulator | Tool-assisted control grounded in legal observations |
| L2 | L1 plus pretrained grasp/contact-generation models | Additional grasp or contact assistance |
| L3 | L1–L2 plus read access to privileged fields exposed by the selected interface | Explicitly privileged evaluation |

These levels are separate from task difficulty and from the v1 platform's three permission axes: observation profile (`rgb`, `rgbd`, `privileged`), frozen tool grants, and experience provenance (`none`, `reference`). An agent running generated code with no perception plugins is still not an L0 agent. A privileged reference controller is not a cold visual agent. RGB-D observations provide depth and validity under their contract; they do not automatically grant object labels, contacts, or hidden goal diagnostics. [3, 4]

Shared accounting also remains separate from success. Current Hanoi and Pocket Cube rules specify an attempt tier selected before evaluation, a 30,000,000-token per-attempt ceiling, and a total ceiling equal to the selected tier times that value. Stricter evaluator limits still apply; the ceiling grants no additional resets or simulator access. The shared visual-reasoning budget is at most 100 image reads per attempt, including helper calls and repeated submissions. These are configured research budgets, not claims about efficient agent behavior. [3]

## 5. Evaluation platform architecture

### 5.1 Public client and trusted runtime

The v1 implementation separates the installable `agentbench_sdk`, the trusted `agentbench_platform`, task environments, and private reference controllers. The public SDK communicates through a Unix socket using newline-delimited JSON. The agent can describe the task, obtain observations and media resources, submit actions, invoke granted tools, and explicitly finish an episode. The full simulator checkout, reference policies, private journal, and host credentials are outside the agent workspace. [4]

The documented container boundary uses a read-only root, non-root execution, a private PID namespace, and no general network access. Narrow sockets connect the SDK and inference relay. These protections belong to the isolated v1 deployment; they should not be assumed for every legacy script or the MuJoCo in-process policy interface. [4, 7]

### 5.2 Actions, time, and lifecycle

Kongming exposes 16 controls, ordered as left arm joints 1–7, left gripper, right arm joints 1–7, and right gripper. Rubik exposes seven Panda joints and one gripper. Arm controls map to `q_target = q_default + 0.5 * action` in radians. Bounds are reported per entry and are not necessarily ±1. Invalid actions are rejected rather than silently clipped. Gripper behavior depends on the selected task mode and must be read from its action specification. [4, 6]

Control runs at 30 Hz with four audited 120 Hz physics substeps per control. Observation, media access, and tool inference do not advance native time; `step` and `step_sequence` do. A sequence contains at most 30 independently checked controls. The trusted runtime owns the initial reset, and the public interface provides no arbitrary reset or native-code execution method. [4]

Request IDs support durable replay of completed responses: retrying the same ID and content returns the recorded response, while changing the content is rejected. An interrupted pending side effect seals the episode rather than executing again. This matters because repeating a network request must not accidentally repeat a robot action. On termination, native resources are finalized, with a bounded result-only gateway period for retrieving terminal responses. [4]

### 5.3 Independent physical scoring

The private journal records actions and native physical samples for subsequent verification. A task's scorer evaluates physical completion, required stability, rule compliance, and hard failures. Independent replay runs in a separate process and recomputes the recorded outcome. In the cited Kongming evidence, this replay uses the same scoring algorithm; it is not an independently designed second physics model or scoring method. [5]

Three kinds of evidence must remain distinct: interface checks establish that observations or tools are delivered correctly; trajectory checks establish properties of a recorded run; model evaluation measures a specified policy across a predefined task set. Passing one kind of check does not establish the others.

## 6. Evaluation protocol and reporting

### 6.1 Freeze the comparison before execution

A comparison should fix task identities, robot embodiment, initial-state distributions, observation schema, permitted tools, experience provenance, policy version, mechanism assistance, and budgets before evaluation. Report each simulator's action semantics and timing instead of treating similarly sized action vectors as interchangeable. Preserve interrupted and failed attempts with their original versions. [3, 4, 7, 8]

Outcome records should separate task success, rule violation, hard physical failure, policy error, timeout, and missing execution. Record resource use independently: control count, simulated time, wall time, model-token volume, image reads, tool calls, and authorized attempts. Wall time depends on hardware and deployment; it is not a hardware-independent efficiency metric.

### 6.2 Four-trial physical-reasoning protocol

The current MuJoCo `four-trial-v1` protocol schedules four independent environments for each `(scenario, mode, operation_profile, base_seed)` group. Each trial retains the same base reset seed while varying prescribed spring stiffness, launcher position, spare/ground ammunition position, and background conditions. The four stiffness values are 22, 24, 26, and 28 N/m. Buildings and targets are not repositioned by these protocol perturbations. [8]

With `public-spring-v1`, the actual spring stiffness and unit are disclosed before the first action to every capability level. Exact private offset vectors and full evaluator manifests are not part of the Vision prompt. Public stiffness and visible scenes can nevertheless reveal associations between conditions, so this is not secure blinding. Because several factors vary together, the protocol is also not a single-factor causal ablation. [8]

For a complete group, success rate is `successful episodes / 4`. Report all four outcomes and whether all four succeeded. For a partial group, final success rate remains null; report observed successes, missing/invalid indices, and the lower bound `observed successes / 4`. Policy errors are invalid attempts; physical violations are valid failures under this protocol. A partial group must not be presented as a completed score. [8]

For example, two successes and two unrun trials produce a 0.5 observed lower bound, not a final 50% result. Two successes and two valid physical failures form a complete group with a 50% result. Four fixed conditions provide a bounded robustness check, not a population estimate over arbitrary seeds and layouts.

### 6.3 Proposed experiments

The following experiments are proposed and have no results in this draft. Compare the same agent across L0–L3 under matched task and resource settings; compare models within a fixed capability level; and measure the effect of feedback using a predeclared intervention that holds observations and budgets otherwise constant. Separate State and Vision, loaded and ground starts, and different mechanisms. Report per-task outcomes before aggregates. Changes to observation access or control abstractions must not be attributed solely to model reasoning.

Use held-out conditions and frozen policy versions to study generalization. Establish minimum sample sizes and uncertainty estimation before collecting stochastic trials; the existing historical inventory and four fixed conditions are insufficient to justify a significance claim. Evidence of recovery should include an observation-dependent change in behavior. A missed shot followed by success alone does not prove replanning. [7, 8]

## 7. Recorded evidence and limitations

### 7.1 Core inventory

The October 8, 2026 review records complete historical physical execution for 82 of 200 core entries: 81 launcher-based tasks and one Panda Hanoi entry, HP-H03. These are engineering-controller records at their original conditions. They are not 82 successful episodes from a common agent evaluation, an overall 41% agent success rate, or current four-trial scores. The atlas reports no accepted complete pass for its 20 bimanual cube entries or 40 standalone-hand Hanoi entries. An absent pass does not prove a task impossible. [2]

The review identifies 22 core tasks with local MP4 files: eight match accepted historical success evidence and fourteen are older-version footage. Video availability alone is not a success criterion. Large ignored artifacts are not automatically available from the source repository, and the website uses scene illustrations rather than relabeling those videos as model demonstrations. A024 retains a documented long-idle drift issue despite its historical pass. [2]

### 7.2 Reference platform evidence

| Record | Outcome | Bound on interpretation |
| --- | --- | --- |
| Kongming SDK assembly | Success; 33,279 controls and 133,116 substeps; independent same-scorer replay | Privileged reference run at its recorded source |
| Kongming SDK disassembly | Success; 19,139 controls and 76,556 substeps; independent replay | Earlier failed disassembly attempts remain failures |
| Real cold coding-agent integration | RGB inputs, self-written SDK code, one control/four substeps, reobservation, and finish verified | Integration passed; puzzle success false |
| Single-Panda Rubik native matrix | Bounded face/sequence/solve cases passed; mandatory 20-move stress episode ended in physical failure | Terminal evidence completes acceptance; it does not imply arbitrary-sequence reliability |
| Thirty public Panda cube cases | Reset acceptance | Initialization only, not thirty solves |

The Kongming assembly/disassembly records report maximum penetration of approximately 1.738 and 1.851 mm respectively, with zero forbidden contact in the accepted runs. Those measurements are tied to the archived trajectories. Assembly evidence was adopted with a documented older-source assessment rather than a fresh current-checkout run. Independent replay does not erase this provenance distinction. [5]

The real coding-agent check demonstrates that RGB images reached a model-facing request, the agent authored control code, issued one legal control, observed again, and explicitly finished. It did not solve the puzzle. The final CLI token aggregate is unavailable in the cited record, and lifecycle termination was not a normal CLI exit. The check cannot establish token-budget compliance, model ranking, or long-horizon task competence. [5]

For Rubik, the current machine-readable native matrix records `complete_with_terminal_stress_failure`. This is more specific than an older platform-guide sentence describing unfinished native acceptance. The 20-move stress case remains a protocol-compliant physical failure with independent recomputation; its existence constrains controller reliability. The separate earlier basic milestone documents historical six-face forms and four short sequences at its own source versions. Neither the milestone nor the completed matrix establishes unconstrained contact-only manipulation. [6]

### 7.3 What remains unestablished

The current evidence does not establish a multi-model leaderboard, a complete four-trial Vision-agent campaign, general success over the 200-task atlas, or transfer to real hardware. Hand-designed curricula and task-demand labels describe intended requirements, not independently calibrated measures of cognition. Reusing task templates across embodiments creates useful comparisons but does not create 200 independent task concepts. Shared private scoring implementations and authored fixtures also limit claims of independent validation and physical realism. [2, 5–8]

## 8. Relation to existing benchmarks

RLBench provides a broad manipulation environment with visual and proprioceptive observations and motion-planner-generated demonstrations. Agent Bench shares the goal of evaluating embodied tasks, while the present report emphasizes the contract between agent tools, physical actions, and retained evidence. This is a difference in emphasis, not a measured performance comparison. [9]

CALVIN studies language-conditioned long-horizon manipulation and composition of skills. It motivates evaluating sequences rather than only isolated actions. Agent Bench likewise treats state tracking across steps as a task requirement, while explicitly distinguishing assistance levels and declared mechanism constraints. [10]

LIBERO studies knowledge transfer in lifelong robot learning through structured task suites. Its training and transfer questions are complementary to the current focus on agent execution under controlled permissions. Agent Bench has not evaluated cross-benchmark transfer to RLBench, CALVIN, or LIBERO, and their success rates should not be pooled with the evidence summarized here. [11]

## 9. Reproducibility and release scope

This report describes the Agent-bench working tree inspected on October 9, 2026, with checkout HEAD `067b6fe47a3e13ebf91900b24f8c52fcd8cf1dbd`. The task atlas and completion inventory include local changes not represented by that commit alone. The website's [source manifest](../data/source-manifest.json) records per-file SHA-256 hashes and whether each source matched HEAD. The [portable catalog](../data/catalog.json) preserves the selected bilingual task definitions and per-task completion notes; the [evidence summary](../data/evidence.json) records counting rules and the original inventory review revision. These exports are a bounded snapshot, not a replacement for native journals. [2]

The website importer reads the source checkout without modifying it, converts native scene images to WebP with aspect-preserving resizing, and records input/output hashes. All task rendering is local to the website; no image-generation system supplies physical evidence. The report's HTML and PDF are generated from this Markdown source so that revisions remain consistent.

For actual benchmark reproduction, follow the task-specific installation and acceptance documentation. Isaac tasks require their compatible Isaac Lab/Sim runtime, whereas the MuJoCo suite has its own dependencies and CPU execution path. Use new run directories, retain exact versions and mechanism settings, and distinguish a dry-run manifest from executed episodes. No new robot simulation or model-evaluation campaign was performed to author this report. [1, 4, 7, 8]

## 10. Conclusion

Agent Bench organizes long-horizon robotic evaluation around explicit task and permission contracts. Its atlas offers varied physical scenarios, while the v1 platform demonstrates an isolated SDK path with independently replayable evidence for a narrower set of extensions. The next scientific milestone is a frozen, auditable agent evaluation with matched inputs, tools, budgets, and retained failures. Existing reference and integration results support that work while leaving broad model performance and generalization open.

## References

1. [Agent-bench repository and project overview](https://github.com/Winniechen2002/Agent-bench). Source: `README.md` and `report.en.md`. The current rules supersede the overview's aspirational tool list.

2. Atlas and execution inventory, local snapshot reviewed October 8, 2026. Portable [task catalog](../data/catalog.json), [evidence summary](../data/evidence.json), and [file provenance manifest](../data/source-manifest.json). Original paths: `docs/task_atlas_200/task_index.en.json`, `docs/task_status_index.json`, and `docs/task_status.en.md`.

3. [Shared capability and budget rules](https://github.com/Winniechen2002/Agent-bench/blob/067b6fe47a3e13ebf91900b24f8c52fcd8cf1dbd/rules.md) and [visual trust boundary](https://github.com/Winniechen2002/Agent-bench/blob/067b6fe47a3e13ebf91900b24f8c52fcd8cf1dbd/Vision_rules.md).

4. [Benchmark platform v1](https://github.com/Winniechen2002/Agent-bench/blob/067b6fe47a3e13ebf91900b24f8c52fcd8cf1dbd/docs/benchmark-platform.md). Architecture, SDK, observation profiles, action units, and lifecycle.

5. [Benchmark v1 evidence and acceptance](https://github.com/Winniechen2002/Agent-bench/blob/067b6fe47a3e13ebf91900b24f8c52fcd8cf1dbd/docs/benchmark-platform-evidence.md). Reference-run and real-agent integration evidence with provenance limitations.

6. [Rubik platform integration](https://github.com/Winniechen2002/Agent-bench/blob/067b6fe47a3e13ebf91900b24f8c52fcd8cf1dbd/docs/rubiks-benchmark-platform.md), [native acceptance matrix](https://github.com/Winniechen2002/Agent-bench/blob/067b6fe47a3e13ebf91900b24f8c52fcd8cf1dbd/docs/rubiks_platform_native_acceptance.json), and [basic milestone v0.1](https://github.com/Winniechen2002/Agent-bench/blob/067b6fe47a3e13ebf91900b24f8c52fcd8cf1dbd/docs/rubiks_cube_milestone_v0.1.md).

7. [Franka Marble environment catalog](https://github.com/Winniechen2002/Agent-bench/blob/067b6fe47a3e13ebf91900b24f8c52fcd8cf1dbd/env/franka_marble/ENVIRONMENT_CATALOG.md). Mechanisms, historical evidence, and valid comparison conditions.

8. [Four-trial test protocol](https://github.com/Winniechen2002/Agent-bench/blob/067b6fe47a3e13ebf91900b24f8c52fcd8cf1dbd/env/franka_marble/TEST_PROTOCOL.en.md). `four-trial-v1` and `public-spring-v1` contracts.

9. Stephen James, Zicong Ma, David Rovick Arrojo, and Andrew J. Davison. [RLBench: The Robot Learning Benchmark & Learning Environment](https://arxiv.org/abs/1909.12271). 2019.

10. Oier Mees, Lukas Hermann, Erick Rosete-Beas, and Wolfram Burgard. [CALVIN: A Benchmark for Language-Conditioned Policy Learning for Long-Horizon Robot Manipulation Tasks](https://arxiv.org/abs/2112.03227). 2021.

11. Bo Liu, Yifeng Zhu, Chongkai Gao, Yihao Feng, Qiang Liu, Yuke Zhu, and Peter Stone. [LIBERO: Benchmarking Knowledge Transfer for Lifelong Robot Learning](https://arxiv.org/abs/2306.03310). 2023.
