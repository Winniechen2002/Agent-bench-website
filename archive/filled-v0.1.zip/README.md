# Agent Bench website

面向国际研究社区的 Agent Bench 项目页和英文技术报告初稿。页面使用英文，支持中文切换。基于相邻的 `Agent-bench` 工作区于 2026-10-09 导出的内容制作。

## 本地预览

无需安装前端依赖或构建：

```bash
python3 -m http.server 4173
```

打开 <http://localhost:4173>。也可以使用 `npm run dev`。请通过 HTTP 访问，任务数据使用 `fetch` 加载，直接双击 `index.html` 的 `file://` 模式不支持该功能。

## 内容

- `index.html`、`styles.css`、`app.js`：响应式宣传页；任务筛选、双语搜索、分批加载、详情弹窗、L0–L3 交互说明。
- `data/catalog.json`：200 项任务的中英文定义、图片和历史执行说明。
- `data/evidence.json`：核心分组、历史完成数量和证据范围。
- `data/source-manifest.json`：来源版本、每份文档的 SHA-256、每张原图和转换图片的 SHA-256。
- `assets/tasks/`：200 张来自原生仿真的 WebP 场景图；没有生成式替换。
- `docs/technical-report.md`：技术报告的可编辑主文件。
- `report.html`：带目录的在线报告。
- `output/pdf/agent-bench-technical-report.pdf`：可下载的排版版报告。

这是一个静态站点；运行时无 CDN、第三方字体、分析脚本或前端框架依赖。所有相对资源路径支持部署到 GitHub Pages 的项目子路径。此版本尚未发布。

## 更新来源

需要 Python 3.10+ 和 Pillow：

```bash
python3 scripts/import_sources.py ../Agent-bench
```

导入器只读源仓库。任务分组或完成数量变化时，它会拒绝旧的计数假设；维护者需核对新证据，同步首页、报告与检查脚本中的结论。导入不是实验复跑。

来源工作区含尚未提交的图谱和状态文件，因此不能仅用 Git HEAD 指代整个快照。清单为各文件记录 `matches_head` 和内容哈希。未将原仓库的私有日志、远程服务器地址或鉴权文件复制到网站。

## 修改报告

编辑 `docs/technical-report.md`，再运行生成器：

```bash
python3 -m pip install -r requirements-report.txt
python3 scripts/build_report.py
```

需要 DejaVu 字体（Linux 常见包为 `fonts-dejavu-extra`）；可通过 `AGENTBENCH_FONT_DIR` 指向包含 DejaVu 字体的目录。生成器也会检测本环境的 bundled 字体。HTML 与 PDF 来自同一份 Markdown。

生成后用 Poppler 检查所有 PDF 页面：

```bash
mkdir -p tmp/pdfs
pdftoppm -scale-to 1000 -png output/pdf/agent-bench-technical-report.pdf tmp/pdfs/report
```

本机 bundled Poppler 要求较新的 glibc；可使用系统 `/usr/bin/pdftoppm` 和 `/usr/bin/pdfinfo`。

## 验证

```bash
python3 scripts/check_site.py
node --check app.js
```

检查包含本地资源/锚点、200 项双语数据、分组计数、82 项历史记录的组成、200 张图片哈希、翻译键和 PDF 存在性。浏览器检查还应覆盖搜索空状态、组合筛选、加载更多、弹窗 Escape/焦点恢复、语言切换与刷新、L0–L3 键盘方向键，以及 390px / 768px / 桌面宽度。

## 证据与发布范围

200 是任务定义数量，82 是特定历史条件下具有完整工程执行记录的任务数量，不能写成模型成功率。孔明锁和单 Panda 魔方是独立于核心图谱的平台扩展。原生场景图不是执行录像。报告保留了魔方压力测试失败、物理机制辅助、四次协议尚无完整 Vision-agent 结果等边界。

本版本没有新增机器人仿真或模型实验。作者、机构、正式论文链接及最终模型结果应由项目团队在正式发布时补齐；页面未虚构这些信息。原项目和资源的权利保持原状，本仓库未擅自为第三方机器人资产授予新的许可证。

部署可以直接托管这些静态文件。发布目录只需首页、样式/脚本、`report.html`、`assets/`、`data/`、报告 Markdown 和 PDF；不要把 `.git/`、`tmp/` 或其他本地工作目录作为公开内容。
