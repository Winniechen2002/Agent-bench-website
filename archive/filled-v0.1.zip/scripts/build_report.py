"""Build readable HTML and a typeset PDF from docs/technical-report.md.

Requires: markdown-it-py, beautifulsoup4, Pillow, reportlab.
Run: python3 scripts/build_report.py
"""
from html import escape
from pathlib import Path
import re
import os

from bs4 import BeautifulSoup, NavigableString
from markdown_it import MarkdownIt
from PIL import Image, ImageDraw, ImageFont
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage, KeepTogether

ROOT = Path(__file__).resolve().parents[1]
font_dirs = [Path(os.environ.get('AGENTBENCH_FONT_DIR', '/usr/share/fonts/truetype/dejavu')),
             Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/share/fonts/truetype']
FONT = next((p for p in font_dirs if (p/'DejaVuSerif-Italic.ttf').exists()), font_dirs[0])
items = [('HP-H03', 'Panda Hanoi'), ('C01-AL', 'Bimanual pocket cube'),
         ('A039', 'Physical reasoning'), ('HN-H02', 'Standalone Sharpa Hanoi')]
montage = Image.new('RGB', (1200, 1050), '#eaece4')
draw = ImageDraw.Draw(montage)
caption_font = ImageFont.truetype(str(FONT/'DejaVuSans.ttf'), 18)
for i, (task, label) in enumerate(items):
    with Image.open(ROOT/'assets/tasks'/f'{task}.webp') as im:
        im.thumbnail((574, 465))
        x, y = (i % 2)*600, (i // 2)*525
        montage.paste(im, (x+(600-im.width)//2, y+10+(465-im.height)//2))
        draw.text((x+20, y+491), f'{task}  /  {label}', fill='#343b31', font=caption_font)
montage.save(ROOT/'assets/report-scenes.jpg', quality=90)

raw = (ROOT/'docs/technical-report.md').read_text()
body = MarkdownIt('default', {'html': False}).render(raw)
soup = BeautifulSoup(body, 'html.parser')
toc = []
for h in soup.find_all('h2'):
    title = h.get_text()
    slug = 'evidence' if title.startswith('7.') else re.sub(r'[^a-z0-9]+', '-', title.lower()).strip('-')
    h['id'] = slug
    toc.append(f'<a href="#{slug}">{escape(title)}</a>')
for table in soup.find_all('table'):
    wrapper = soup.new_tag('div', attrs={'class': 'report-table-scroll', 'tabindex': '0', 'role': 'region', 'aria-label': 'Report table'})
    table.wrap(wrapper)
for link in soup.find_all('a', href=True):
    if link['href'].startswith('../'):
        link['href'] = link['href'][3:]
for img in soup.find_all('img'):
    img['src'] = img['src'].removeprefix('../')
    img['loading'] = 'lazy'

html = '''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="Agent Bench technical report: task design, capability levels, trusted evaluation, and bounded physical evidence.">
<meta name="theme-color" content="#f5f3ed"><title>Agent Bench — Technical Report</title>
<link rel="icon" href="assets/favicon.svg"><link rel="stylesheet" href="styles.css"><link rel="stylesheet" href="report.css"></head>
<body><a class="skip-link" href="#report">Skip to report</a>
<header class="header"><a class="brand" href="index.html"><span class="brand-mark" aria-hidden="true">a<span>↗</span></span> agent<span class="brand-light">bench</span></a><div class="header-actions"><a href="index.html">← Project website</a><a href="output/pdf/agent-bench-technical-report.pdf" download>Download PDF ↓</a></div></header>
<main class="report-layout wrap"><aside class="report-sidebar"><span class="section-label">IN THIS REPORT</span><nav aria-label="Report contents">''' + ''.join(toc) + '''</nav><a class="report-source" href="docs/technical-report.md" download>Download Markdown ↓</a><a class="report-source" href="data/source-manifest.json">Source provenance ↗</a></aside>
<article class="report-body" id="report"><div class="report-status"><span class="status-dot"></span> RESEARCH DRAFT / V0.1</div>''' + str(soup) + '''<div class="report-end"><a href="index.html#tasks">← Explore the task atlas</a><a href="output/pdf/agent-bench-technical-report.pdf" download>Download PDF ↓</a></div></article></main>
<footer class="footer wrap"><div class="footer-bottom"><span>AGENT BENCH · OCTOBER 2026</span><span>Research draft · No model leaderboard claimed</span></div></footer></body></html>'''
(ROOT/'report.html').write_text(html)

# Use a Unicode font family for mathematical symbols and consistent PDF rendering.
for name, file in [('Body','DejaVuSerif.ttf'),('Body-Bold','DejaVuSerif-Bold.ttf'),
                   ('Body-Italic','DejaVuSerif-Italic.ttf'),('Body-BoldItalic','DejaVuSerif-BoldItalic.ttf'),
                   ('Sans','DejaVuSans.ttf'),('Sans-Bold','DejaVuSans-Bold.ttf'),('Mono','DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(name, str(FONT/file)))
pdfmetrics.registerFontFamily('Body', normal='Body', bold='Body-Bold', italic='Body-Italic', boldItalic='Body-BoldItalic')
pdfmetrics.registerFontFamily('Sans', normal='Sans', bold='Sans-Bold', italic='Sans', boldItalic='Sans-Bold')
ink,muted,accent=colors.HexColor('#252720'),colors.HexColor('#696e64'),colors.HexColor('#c64828')
styles = {
    'p': ParagraphStyle('BodyText',fontName='Body',fontSize=9.4,leading=14.7,textColor=ink,spaceAfter=8.4,splitLongWords=True),
    'h1': ParagraphStyle('Title',fontName='Sans',fontSize=25,leading=30,textColor=ink,spaceAfter=17,keepWithNext=True),
    'h2': ParagraphStyle('Section',fontName='Sans-Bold',fontSize=14,leading=19,textColor=ink,spaceBefore=18,spaceAfter=9,keepWithNext=True),
    'h3': ParagraphStyle('Subsection',fontName='Sans-Bold',fontSize=10.5,leading=15,textColor=ink,spaceBefore=12,spaceAfter=7,keepWithNext=True),
    'caption': ParagraphStyle('Caption',fontName='Sans',fontSize=8,leading=11.5,textColor=muted,spaceAfter=12),
    'table': ParagraphStyle('Table',fontName='Sans',fontSize=7.7,leading=11,textColor=ink),
    'ref': ParagraphStyle('Reference',fontName='Body',fontSize=8.3,leading=12.3,textColor=ink,spaceAfter=7),
}

def inline(el):
    if isinstance(el, NavigableString):
        return escape(str(el).replace('–','-').replace('—','-').replace('‑','-'))
    name=el.name
    text=''.join(inline(c) for c in el.children)
    if name in ['strong','b']: return '<b>'+text+'</b>'
    if name in ['em','i']: return '<i>'+text+'</i>'
    if name=='code': return '<font name="Mono" size="8">'+text+'</font>'
    if name=='a':
        href=el.get('href','')
        if not href.startswith(('http:', 'https:', '#')): href='../../'+href.removeprefix('../')
        return f'<link href="{escape(href,quote=True)}" color="#a2402a">{text}</link>'
    if name=='br': return '<br/>'
    return text

story=[]
pdf_soup=BeautifulSoup(body,'html.parser')
in_refs=False
for el in pdf_soup.children:
    if isinstance(el,NavigableString):continue
    if el.name in ['h1','h2','h3']:
        story.append(Paragraph(inline(el),styles[el.name]))
        if el.get_text()=='References':in_refs=True
    elif el.name=='p':
        img=el.find('img')
        if img:
            story.append(Spacer(1,6))
            figure=RLImage(str(ROOT/img['src'].removeprefix('../')),width=462,height=404.25)
            figure.keepWithNext=True
            story.append(figure)
            continue
        style='caption' if el.find('em',recursive=False) and el.get_text().startswith('Figure') else 'p'
        story.append(Paragraph(inline(el),styles[style]))
    elif el.name=='table':
        rows=[]
        for tr in el.find_all('tr'):
            rows.append([Paragraph(inline(td),styles['table']) for td in tr.find_all(['th','td'])])
        width=481
        widths=[width*.29,width*.15,width*.56] if 'Atlas group' in el.get_text() else [width*.19,width*.47,width*.34]
        if 'Record' in el.get_text():widths=[width*.25,width*.42,width*.33]
        table=Table(rows,colWidths=widths,repeatRows=1,hAlign='LEFT')
        table.setStyle(TableStyle([
            ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e7ebdf')),
            ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),
            ('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),5),
            ('BOTTOMPADDING',(0,0),(-1,-1),5),
            ('LINEBELOW',(0,0),(-1,0),.7,colors.HexColor('#b8c2ad')),
            ('LINEBELOW',(0,1),(-1,-1),.35,colors.HexColor('#d7dccf')),
        ]))
        table_block=[Spacer(1,5),table,Spacer(1,11)]
        if story and isinstance(story[-1],Paragraph) and story[-1].style.name in ['Section','Subsection']:
            table_block.insert(0,story.pop())
        story.append(KeepTogether(table_block))
    elif el.name in ['ol','ul']:
        start=int(el.get('start',1))
        for i,li in enumerate(el.find_all('li',recursive=False),start):
            text=inline(li).strip()
            story.append(Paragraph(f'{i}. '+text,styles['ref' if in_refs else 'p']))

def page(canvas,doc):
    w,h=A4
    canvas.saveState()
    canvas.setStrokeColor(colors.HexColor('#d4d9cb'));canvas.setLineWidth(.5)
    canvas.line(57,h-37,w-57,h-37)
    canvas.setFont('Sans',7);canvas.setFillColor(muted)
    canvas.drawString(57,h-28,'AGENT BENCH')
    canvas.drawRightString(w-57,h-28,'TECHNICAL REPORT / DRAFT V0.1')
    canvas.line(57,40,w-57,40)
    canvas.drawString(57,27,'October 9, 2026  |  Simulation research')
    canvas.drawRightString(w-57,27,str(doc.page))
    canvas.restoreState()

out=ROOT/'output/pdf/agent-bench-technical-report.pdf'
out.parent.mkdir(parents=True,exist_ok=True)
doc=SimpleDocTemplate(str(out),pagesize=A4,rightMargin=57,leftMargin=57,topMargin=57,bottomMargin=56,
                      title='Agent Bench: Evaluating Agents through Long-Horizon Robotic Tasks',
                      subject='Draft v0.1: task contracts, capability levels, platform architecture, and evidence')
doc.build(story,onFirstPage=page,onLaterPages=page)
print('Generated report.html and output/pdf/agent-bench-technical-report.pdf')
