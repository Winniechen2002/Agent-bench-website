"""Check portable assets, internal links, evidence counts, and source hashes.

Uses only the standard library; no simulator or browser needed.
"""
from collections import Counter
from hashlib import sha256
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit
import json
import re

ROOT = Path(__file__).resolve().parents[1]
errors=[]

class Page(HTMLParser):
    def __init__(self, path):
        super().__init__();self.path=path;self.ids=[];self.links=[];self.images=[];self.keys=set()
        self.feed(path.read_text())
    def handle_starttag(self, tag, attrs):
        d=dict(attrs)
        if 'id' in d:self.ids.append(d['id'])
        if 'data-i18n' in d:self.keys.add(d['data-i18n'])
        for attr in ['href','src']:
            if d.get(attr):self.links.append(d[attr])
        if tag=='img':
            self.images.append(d)
            if 'alt' not in d:errors.append(f'Missing alt: {self.path.name} {d}')

pages={p.name:Page(p) for p in ROOT.glob('*.html')}
for name,page in pages.items():
    assert len(page.ids)==len(set(page.ids)),f'Duplicate IDs: {name}'
    for link in page.links:
        u=urlsplit(link)
        if u.scheme or u.netloc:continue
        target=(ROOT/unquote(u.path)) if u.path else page.path
        if not target.is_file():errors.append(f'{name}: missing {link}')
        if u.fragment and target.suffix=='.html':
            parsed=pages.get(target.name) or Page(target)
            if unquote(u.fragment) not in parsed.ids:errors.append(f'{name}: broken anchor {link}')

catalog=json.loads((ROOT/'data/catalog.json').read_text())
evidence=json.loads((ROOT/'data/evidence.json').read_text())
manifest=json.loads((ROOT/'data/source-manifest.json').read_text())
assert len(catalog)==len({t['id'] for t in catalog})==200
assert dict(Counter(t['group'] for t in catalog))==evidence['groups']
assert sum(t['completed'] for t in catalog)==evidence['historical_completed']==82
assert Counter(t['group'] for t in catalog if t['completed'])=={'birds':81,'panda':1}
for t in catalog:
    assert (ROOT/t['image']).is_file(),t['id']
    for lang in ['en','zh']:
        assert t[lang]['title'] and t[lang]['lines'] and t[lang]['status'],(t['id'],lang)
for asset in manifest['media']:
    assert sha256((ROOT/asset['output']).read_bytes()).hexdigest()==asset['output_sha256'],asset['id']
js=(ROOT/'app.js').read_text()
for key in pages['index.html'].keys:
    if not re.search(r'\b'+re.escape(key)+r'\s*:',js):errors.append('Missing Chinese translation: '+key)
pdf=ROOT/'output/pdf/agent-bench-technical-report.pdf'
assert pdf.read_bytes().startswith(b'%PDF-')
assert pdf.stat().st_size>20000
assert 'not a model success rate' in (ROOT/'index.html').read_text().lower()
assert 'current four-trial' in (ROOT/'docs/technical-report.md').read_text()
if errors:raise SystemExit('\n'.join(errors))
print(f'PASS: {len(pages)} HTML pages; local assets and anchors; 200 bilingual tasks; 82 scoped historical passes; 200 media hashes; translations; PDF.')
